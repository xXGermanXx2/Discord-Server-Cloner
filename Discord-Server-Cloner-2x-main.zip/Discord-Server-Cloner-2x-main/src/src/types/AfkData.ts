export interface AfkData {
    name: string;
    timeout: number;
}
